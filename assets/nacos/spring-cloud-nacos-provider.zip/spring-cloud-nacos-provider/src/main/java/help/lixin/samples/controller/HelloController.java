package help.lixin.samples.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RefreshScope
public class HelloController {
	private Logger logger = LoggerFactory.getLogger(HelloController.class);

	@Value("${useLocalCache:false}")
	private boolean useLocalCache;

	@Autowired
	private Environment env;

	@GetMapping("/hello")
	public String hello() {
		String jdbcurl = env.getProperty("spring.datasource.url", "");
		logger.debug("useLocalCache", useLocalCache);
		return "Hello World!!! " + useLocalCache + "  jdbcUrl:" + jdbcurl;
	}
}