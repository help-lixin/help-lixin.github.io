package help.lixin.samples.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RefreshScope
public class ConsumerController {
	private Logger logger = LoggerFactory.getLogger(ConsumerController.class);

	@Autowired
	private RestTemplate restTemplate;

	@Value("${remoteSwitch:true}")
	private boolean remoteSwitch;

	@Value("${showMsg:local consumer...}")
	private String showMsg;

	@GetMapping("/consumer")
	public String index() {
		logger.debug("consumer....");
		String url = "http://test-provider/hello";
		String result = restTemplate.getForEntity(url, String.class).getBody();
		return showMsg + result;
	}
}
