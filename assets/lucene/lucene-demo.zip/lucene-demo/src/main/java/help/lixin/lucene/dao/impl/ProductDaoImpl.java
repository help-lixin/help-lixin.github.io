package help.lixin.lucene.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import help.lixin.lucene.dao.IProductDao;
import help.lixin.lucene.model.Product;

public class ProductDaoImpl implements IProductDao {

	private String sql = new StringBuilder() //
			.append(" SELECT  ") //
			.append(" pid,  ") //
			.append(" pname,  ") //
			.append(" catalog,  ") //
			.append(" catalog_name,  ") //
			.append(" price,  ") //
			.append(" number,  ") //
			.append(" description,  ") //
			.append(" picture,  ") //
			.append(" release_time  ") //
			.append(" FROM products  ") //
			.toString();

	@Override
	public List<Product> products() {
		List<Product> products = new ArrayList<Product>(0);
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/solr?characterEncoding=UTF-8",
					"root", "123456");
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Product product = new Product();
				product.setPid(rs.getInt("pid"));
				product.setPname(rs.getString("pname"));
				product.setCatalog(rs.getInt("catalog"));
				product.setCatalogName(rs.getString("catalog_name"));
				product.setPrice(rs.getDouble("price"));
				product.setNumber(rs.getInt("number"));
				product.setDescription(rs.getString("description"));
				product.setPicture(rs.getString("picture"));
				product.setReleaseTime(new Date(rs.getDate("release_time").getTime()));
				products.add(product);
			}
		} catch (

		Exception e) {
		}
		return products;
	}
}
