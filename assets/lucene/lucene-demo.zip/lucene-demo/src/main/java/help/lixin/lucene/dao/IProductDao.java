package help.lixin.lucene.dao;

import java.util.List;

import help.lixin.lucene.model.Product;

public interface IProductDao {
	List<Product> products();
}
