package help.lixin.lucene.service;

import java.nio.file.Paths;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.Term;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.junit.Test;

public class IndexDeleteTest {

	@Test
	public void testDelete() throws Exception {
		// 3. 创建分词器(标准分词器,对英文分词效果后,对:中文是单字分词)
		Analyzer analyzer = new StandardAnalyzer();
		
		// 4. 创建索引库存放目录
		String indexDir = "/Users/lixin/Workspace/lucene-demo/indexDir";
		Directory directory = FSDirectory.open(Paths.get(indexDir));

		// 5. 创建IndexWriterConfig,指定:分词器
		IndexWriterConfig config = new IndexWriterConfig(analyzer);

		// 6. 创建IndexWriter,指定:索引目录和中文分词器
		IndexWriter writer = new IndexWriter(directory, config);

		// 7. 修改文档
		// term: 修改条件
		// doc:新的document
		long r = writer.deleteDocuments(new Term("pid", "1"));
//		writer.deleteAll();
		
		// 8. 释放资源
		writer.flush();
		writer.close();
	}
}
