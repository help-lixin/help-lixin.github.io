package help.lixin.lucene.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.DoublePoint;
import org.apache.lucene.document.IntPoint;
import org.apache.lucene.document.LongPoint;
import org.apache.lucene.document.Field.Store;
import org.apache.lucene.document.StoredField;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.junit.Before;
import org.junit.Test;
import org.wltea.analyzer.lucene.IKAnalyzer;

import help.lixin.lucene.dao.IProductDao;
import help.lixin.lucene.dao.impl.ProductDaoImpl;
import help.lixin.lucene.model.Product;

public class IndexWriterTest {

	private IProductDao productDao = null;
	String indexDir = "/Users/lixin/Workspace/lucene-demo/indexDir";
	
	@Before
	public void before() {
		try {
			File indexDirFile = new File(indexDir);
			FileUtils.deleteDirectory(indexDirFile);
			indexDirFile.mkdirs();
		} catch (IOException e) {
			e.printStackTrace();
		}
		productDao = new ProductDaoImpl();
	}

	@Test
	public void testWriter() throws Exception {
		// 1. 采集数据
		List<Product> products = productDao.products();

		// 2. 创建文档对象
		List<Document> documents = new ArrayList<Document>(0);
		for (Product product : products) {
			Document document = buildDocument(product);
			documents.add(document);
		}

		// 3. 创建分词器(标准分词器,对英文分词效果后,对:中文是单字分词)
		Analyzer analyzer = new IKAnalyzer();

		// 4. 创建索引库存放目录
		Directory directory = FSDirectory.open(Paths.get(indexDir));

		// 5. 创建IndexWriterConfig,指定:分词器
		IndexWriterConfig config = new IndexWriterConfig(analyzer);

		// 6. 创建IndexWriter,指定:索引目录和中文分词器
		IndexWriter writer = new IndexWriter(directory, config);

		// 7. 写入文档
		writer.addDocuments(documents);
		
		// 8. 释放资源
		writer.flush();
		writer.close();
	}

	/**
	 * 构建:Document
	 * 
	 * @param product
	 * @return
	 */
	private Document buildDocument(Product product) {
		Document document = new Document();
		/**
		 * 是否分词:N
		 * 是否索引:Y
		 * 是否存储:Y
		 */
		
		document.add(new LongPoint("pid", product.getPid()));
		document.add(new StoredField("pid", product.getPid()));
		
		
		/**
		 * 是否分词:Y
		 * 是否索引:Y
		 * 是否存储:Y
		 */
		document.add(new TextField("pname", product.getPname(), Store.YES));
		
		/**
		 * 是否分词:N
		 * 是否索引:Y
		 * 是否存储:Y
		 */
		document.add(new IntPoint("catalog", product.getCatalog()));
		document.add(new StoredField("catalog", product.getCatalog()));
		
		/**
		 * 是否分词:Y
		 * 是否索引:Y
		 * 是否存储:Y
		 */
		document.add(new TextField("catalogName", product.getCatalogName(), Store.YES));
		
		/**
		 * 是否分词:Y(好像没得给配置,Lucene算法规定了的)
		 * 是否索引:Y
		 * 是否存储:Y
		 */
		document.add(new DoublePoint("price", product.getPrice()));
		document.add(new StoredField("price", product.getPrice()));
		
		/**
		 * 是否分词:N
		 * 是否索引:Y
		 * 是否存储:Y
		 */
		document.add(new IntPoint("number", product.getNumber()));
		document.add(new StoredField("number", product.getNumber()));
		
		/**
		 * 是否分词:Y
		 * 是否索引:Y
		 * 是否存储:N
		 */
		document.add(new TextField("description", String.valueOf(product.getDescription()), Store.NO));
		
		/**
		 * 是否分词:N
		 * 是否索引:Y
		 * 是否存储:Y
		 */
		document.add(new StringField("picture", product.getPicture(), Store.YES));
		
		/**
		 * 是否分词:N
		 * 是否索引:Y
		 * 是否存储:Y
		 */
		document.add(new LongPoint("releaseTime", product.getReleaseTime().getTime()));
		document.add(new StoredField("releaseTime", product.getReleaseTime().getTime()));
		return document;
	}
}
