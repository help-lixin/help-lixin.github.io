package help.lixin.lucene.service;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.Optional;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.DoublePoint;
import org.apache.lucene.document.LongPoint;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.BooleanClause.Occur;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.junit.Test;
import org.wltea.analyzer.lucene.IKAnalyzer;

public class QueryTest {
	
	/**
	 * 文本查询
	 * @throws Exception
	 */
	@Test
	public void tetsQuery() throws Exception {
		Analyzer analyzer = new IKAnalyzer();

		// 2.创建查询对象
		QueryParser queryParser = new QueryParser("pname", analyzer);

		// 3.设置搜索关键词
		// SELECT * FROM xxx WHERE pname LIKE '%真皮%' OR pname LIKE '%纹圆%';
		// pname:真皮
		// 默认情况下:词汇之间是OR,求的是交集.
		Query query = queryParser.parse("真皮 OR 纹圆");

		// 4. 指定索引库位置
		String indexDir = "/Users/lixin/Workspace/lucene-demo/indexDir";
		Directory directory = FSDirectory.open(Paths.get(indexDir));

		// 5. 打开索引库,并转换成:IndexReader
		IndexReader reader = DirectoryReader.open(directory);

		// 6. 创建搜索对象
		IndexSearcher searcher = new IndexSearcher(reader);

		// 7. 搜索并返回结果
		TopDocs topDocs = searcher.search(query, 1000);

		// 8. 转换结果集
		long totalHits = topDocs.totalHits;
		ScoreDoc[] docs = topDocs.scoreDocs;
		Optional<ScoreDoc[]> optional =  Optional.of(docs);
		optional.ifPresent((item)->{
			for(ScoreDoc doc : item) {
				// Lucene为Document分配的唯一ID,并非业务:pid
				int docID = doc.doc;
				try {
					Document document = reader.document(docID);
					System.out.println("==================================================");
					System.out.println("  pid: "+document.get("pid"));
					System.out.println("  pname: "+document.get("pname"));
				} catch (IOException e) {
				}
			}
		});
		
		System.err.println("totalHits:" + totalHits);
		// 9. 释放资源
		reader.close();
	}
	
	/**
	 * 数值范围查询
	 * @throws Exception
	 */
	@Test
	public void testBetweenQuery() throws Exception {
		// 包含起始值和结束值的
		// SELECT * FROM xxx WHERE price >= 100 AND price <= 200;
		// 2.创建查询对象
		Query query  = DoublePoint.newRangeQuery("price", 100, 200);

		// 4. 指定索引库位置
		String indexDir = "/Users/lixin/Workspace/lucene-demo/indexDir";
		Directory directory = FSDirectory.open(Paths.get(indexDir));

		// 5. 打开索引库,并转换成:IndexReader
		IndexReader reader = DirectoryReader.open(directory);

		// 6. 创建搜索对象
		IndexSearcher searcher = new IndexSearcher(reader);

		// 7. 搜索并返回结果
		TopDocs topDocs = searcher.search(query, 1000);

		// 8. 转换结果集
		long totalHits = topDocs.totalHits;
		ScoreDoc[] docs = topDocs.scoreDocs;
		Optional<ScoreDoc[]> optional =  Optional.of(docs);
		optional.ifPresent((item)->{
			for(ScoreDoc doc : item) {
				// Lucene为Document分配的唯一ID,并非业务:pid
				int docID = doc.doc;
				try {
					Document document = reader.document(docID);
					System.out.println("==================================================");
					System.out.println("  pid: "+document.get("pid"));
					System.out.println("  pname: "+document.get("pname"));
					System.out.println("  price: "+document.get("price"));
				} catch (IOException e) {
				}
			}
		});
		
		System.err.println("totalHits:" + totalHits);
		// 9. 释放资源
		reader.close();
	}
	
	
	/**
	 * 根据主键查询
	 * @throws Exception
	 */
	@Test
	public void testPrimaryKeyQuery() throws Exception {
		// 包含起始值和结束值的
		// SELECT * FROM xxx WHERE price >= 100 AND price <= 200;
		// 2.创建查询对象
		Query query  = LongPoint.newExactQuery("pid", 316);

		// 4. 指定索引库位置
		String indexDir = "/Users/lixin/Workspace/lucene-demo/indexDir";
		Directory directory = FSDirectory.open(Paths.get(indexDir));

		// 5. 打开索引库,并转换成:IndexReader
		IndexReader reader = DirectoryReader.open(directory);

		// 6. 创建搜索对象
		IndexSearcher searcher = new IndexSearcher(reader);

		// 7. 搜索并返回结果
		TopDocs topDocs = searcher.search(query, 1000);

		// 8. 转换结果集
		long totalHits = topDocs.totalHits;
		ScoreDoc[] docs = topDocs.scoreDocs;
		Optional<ScoreDoc[]> optional =  Optional.of(docs);
		optional.ifPresent((item)->{
			for(ScoreDoc doc : item) {
				// Lucene为Document分配的唯一ID,并非业务:pid
				int docID = doc.doc;
				try {
					Document document = reader.document(docID);
					System.out.println("==================================================");
					System.out.println("  pid: "+document.get("pid"));
					System.out.println("  pname: "+document.get("pname"));
					System.out.println("  price: "+document.get("price"));
				} catch (IOException e) {
				}
			}
		});
		
		System.err.println("totalHits:" + totalHits);
		// 9. 释放资源
		reader.close();
	}
	
	/**
	 * 组合查询
	 * @throws Exception
	 */
	@Test
	public void testComposeQuery() throws Exception{
		Analyzer analyzer = new IKAnalyzer();

		// 2.创建查询对象
		QueryParser queryParser = new QueryParser("pname", analyzer);

		// 3.设置搜索关键词
		// SELECT * FROM xxx WHERE pname LIKE '%真皮%' AND (price >= 10 AND price<=60 );
		// pname:真皮
		// 默认情况下:词汇之间是OR,求的是交集.
		Query likeQuery = queryParser.parse("真皮");
		// price >= 100 and price <= 200
		Query betweenQuery = DoublePoint.newRangeQuery("price", 10, 60);

		BooleanQuery query = new BooleanQuery.Builder() //
				// MUST == AND
				// SHOULD == OR
				// MUST_NOT == NOT  
				.add(likeQuery, Occur.MUST)
				.add(betweenQuery,Occur.MUST)
				.build();
		
		// 4. 指定索引库位置
		String indexDir = "/Users/lixin/Workspace/lucene-demo/indexDir";
		Directory directory = FSDirectory.open(Paths.get(indexDir));

		// 5. 打开索引库,并转换成:IndexReader
		IndexReader reader = DirectoryReader.open(directory);

		// 6. 创建搜索对象
		IndexSearcher searcher = new IndexSearcher(reader);

		// 7. 搜索并返回结果
		TopDocs topDocs = searcher.search(query, 1000);

		// 8. 转换结果集
		long totalHits = topDocs.totalHits;
		ScoreDoc[] docs = topDocs.scoreDocs;
		Optional<ScoreDoc[]> optional =  Optional.of(docs);
		optional.ifPresent((item)->{
			for(ScoreDoc doc : item) {
				// Lucene为Document分配的唯一ID,并非业务:pid
				int docID = doc.doc;
				try {
					Document document = reader.document(docID);
					System.out.println("==================================================");
					System.out.println("  pid: "+document.get("pid"));
					System.out.println("  pname: "+document.get("pname"));
					System.out.println("  price: "+document.get("price"));
				} catch (IOException e) {
				}
			}
		});
		
		System.err.println("totalHits:" + totalHits);
		// 9. 释放资源
		reader.close();
	}
}
