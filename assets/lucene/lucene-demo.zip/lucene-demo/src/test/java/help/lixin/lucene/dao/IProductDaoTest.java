package help.lixin.lucene.dao;

import java.util.List;

import org.junit.Test;

import help.lixin.lucene.dao.impl.ProductDaoImpl;
import help.lixin.lucene.model.Product;
import static junit.framework.Assert.*;

public class IProductDaoTest {

	@Test
	public void test() {
		IProductDao productDao = new ProductDaoImpl();
		List<Product> result = productDao.products();
		assertTrue(result.size() > 0);
	}
}
