import Vue from 'vue'
import VueRouter from 'vue-router'

// 导入业务组件
import Login from '../views/Login'
import Main from '../views/Main'

Vue.use(VueRouter);

// 定义路由
const routes = [
    { path: "/login", name: "Login", component: Login } ,
    { path: "/main", name: "Main", component: Main }
];

export default new VueRouter({
    routes: routes,
    mode: "history"
});
