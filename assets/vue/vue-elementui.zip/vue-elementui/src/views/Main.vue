<template>
    <div>
         <el-container>

            <!-- <el-aside>：侧边栏容器开始  -->
            <el-aside width="200px">
                <el-menu :default-openeds="['1']">
                    <el-submenu index="1">
                        <template slot="title"><i class="el-icon-setting"></i>用户管理</template>
                        <el-menu-item-group>
                            <el-menu-item index="1-1">
                                <router-link to="/user/add">添加用户</router-link>
                            </el-menu-item>
                            <el-menu-item index="1-2">
                                <!-- <router-link to="/user/modify/1">修改用户</router-link> -->
                                <router-link :to="{name:'UserModify',params:{id:2}}">修改用户</router-link>
                            </el-menu-item>
                            <el-menu-item index="1-4">
                                <router-link to="/user/list">查看用户列表</router-link>
                            </el-menu-item>
                        </el-menu-item-group>
                    </el-submenu>

                    <el-submenu index="2">
                        <template slot="title"><i class="el-icon-menu"></i>角色管理</template>
                        <el-menu-item-group>
                            <el-menu-item index="1-1">添加角色</el-menu-item>
                            <el-menu-item index="1-2">修改角色</el-menu-item>
                            <el-menu-item index="1-3">删除角色</el-menu-item>
                            <el-menu-item index="1-4">查看角色列表</el-menu-item>
                        </el-menu-item-group>
                    </el-submenu>
                </el-menu>
            </el-aside>
            <!-- <el-aside>：侧边栏容器结束  -->
            
            <!-- 创建新的容器开始 -->
            <el-container>
                <!-- <el-header>:顶栏容器开始 -->
                <el-header style="text-align: right; font-size: 12px">
                    <el-dropdown>
                        <i class="el-icon-setting" style="margin-right: 15px"></i>
                        <el-dropdown-menu slot="dropdown">
                        <el-dropdown-item>用户中心</el-dropdown-item>
                        <el-dropdown-item>
                            <router-link to="/logout">退出登录</router-link>
                        </el-dropdown-item>
                        </el-dropdown-menu>
                    </el-dropdown>
                    <span>{{userName}}</span>
                </el-header>
                <!-- <el-header>:顶栏容器结束 -->
                
                <!-- <el-main>：主要区域容器开始 -->
                <el-main>
                    <router-view/>
                </el-main>
                <!-- <el-main>：主要区域容器结束 -->

            </el-container>
            <!-- 创建新的容器结束 -->

        </el-container>
    </div>   
</template>

<script>
export default {
    props : ['userName'] ,
    name : "Main",
    data() {
        return {
            
        }// end return 
    }
}
</script>

<style lang="scss" scoped>
  .el-header {
    background-color: #B3C0D1;
    color: #333;
    line-height: 30px;
  }
  
  .el-aside {
    color: #333;
  }
</style>