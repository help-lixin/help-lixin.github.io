<template>
    <div>
        用户信息:<br/>
        userName :  <input type="text" v-model="from.userName"> <br/>
        age :  <input type="text" v-model="from.age"> <br/>
    </div>
</template>

<script>
export default {
    props:['id'],
    name : "UserModify",
    data(){
        return {
            from:{
                id : "",
                userName : "",
                age : 0
            }
        }
    },
    beforeRouteEnter : (to,from,next)=>{
        console.log("进入用户修改页面");
        // 继续往下执行
        next(vm=>{
            vm.getData(vm.id);
        });
    },
    beforeRouteLeave:(to,from,next)=>{
        console.log("离开用户修改页面");
        next();
    },
    methods : {
        getData:function(id){
            let url = "http://localhost:8080/devApi/user/" + id ;
            this.axios({
                method : "GET",
                url : url
            }).then((res)=>{
                if(res.status == 200){
                    this.from = res.data;
                }
            }).catch((err)=>{
                console.log(err);
            });
        }
    }    
}
</script>

<style>

</style>