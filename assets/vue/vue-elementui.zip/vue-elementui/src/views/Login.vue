<template>
    <div>
        <!-- ref:相当于ID   model:v-bind:model="from"   -->
        <el-form ref="form" :model="form" :rules="rules"  class="login-box">
            <h3 class="login-title">欢迎登录</h3>
            <el-form-item label="用户名:" prop="userName">
                <el-input placeholder="请输入用户名" v-model="form.userName"></el-input>
            </el-form-item>
            <el-form-item label="密码:"  prop="password">
                <el-input placeholder="请输入密码" v-model="form.password" show-password>></el-input>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="onSubmit('form');">登录</el-button>
                <el-button @click="onCancel('form');">取消</el-button>
            </el-form-item>
        </el-form>
    </div>    
</template>

<script>
export default {
    name : "Login",
    data() {
      return {
          form: {
            userName : '',
            password : '',
        },
        rules: {
            // 这里的名称要与prop定义要相同
            userName: [
                { required: true, message: '请输入用户名', trigger: 'blur' }
            ],
            password: [
                { required: true, message: '请输入密码', trigger: 'blur' }
            ]
        }
      }
    },
    methods : {
        onSubmit(formName){
            this.$refs[formName].validate((valid) => {
            if (valid) {
                // 跳转到首页:/main
                this.$router.push("/main");
            } else {
                // 发送警告消息.
                this.$message({message: '请输入用户名或者密码',type: 'warning'});
                return false;
            }
            });
        },
        onCancel(formName){
            this.$refs[formName].resetFields();
        }
    }
}
</script>

<style lang="scss" scoped>
.login-box {
    width: 350px;
    margin: 120px auto;
    border: 1px solid #DCDFE6;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 30px #DCDFE6;
}

.login-title {
    text-align: center;
}
</style>