<template>
    <div>
        404 Page Not Found
    </div>
</template>

<script>
export default {
    name : "NotFound"
}
</script>