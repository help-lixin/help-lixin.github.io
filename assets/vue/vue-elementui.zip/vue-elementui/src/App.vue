<template>
  <div id="app">
    <!-- 配置路由组件 -->
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App',
}
</script>

<style>

</style>
