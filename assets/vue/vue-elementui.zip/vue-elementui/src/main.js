import Vue from 'vue'
import VueRouter from 'vue-router'
// 导入路由配置
import router from './router/index.js'
import App from './App'

// 导入axios
import axios from 'axios'


import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';


Vue.use(VueRouter);
Vue.use(ElementUI);
// 声明使用axios
Vue.prototype.axios=axios;

Vue.config.productionTip = false

new Vue({
  el: '#app',
  router,
  render: h => h(App)
})
