import Vue from 'vue'
import VueRouter from 'vue-router'
// 引入组件:Content
import Content from '../components/Content'

Vue.use(VueRouter);

// 4. 统一路由定义配置文件
export default new VueRouter({
    routes: [
        // 定义路由信息(path:路径   component:路由组件)
        { path: "/content", name: "Content", component: Content }
    ],
    mode : "history"
});