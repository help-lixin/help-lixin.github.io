import Vue from 'vue'
// 1. 引入vue-router
import VueRouter from 'vue-router'
import App from './App'

// 5. 引入路由配置信息
// import router from './router/index'
import router from './router'

// 2. 使用vue-router
Vue.use(VueRouter);


Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})
