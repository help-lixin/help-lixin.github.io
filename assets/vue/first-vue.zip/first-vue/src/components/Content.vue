<template>
    <div>
        {{message}}
    </div>
</template>

<script>
// 3. 定义组件
export default {
    name : "Content",
    data : function(){
        return { 
            message:"我是内容"
        }
    }
}
</script>