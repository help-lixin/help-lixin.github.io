import Vue from 'vue'
import VueRouter from 'vue-router'

// 导入业务组件
import Login from '../views/Login'
import Main from '../views/Main'

// 404页面
import NotFound from '../views/404'


// 用户模块
import UserList from '../views/User/UserList'
import UserAdd from '../views/User/UserAdd'
import UserModify from '../views/User/UserModify'

Vue.use(VueRouter);

// 定义路由
const routes = [
    { path : "/login", name: "Login", component: Login },
    // { path : "/logout" ,redirect: "/login" },
    {
        // 配置子路由
        path: "/main", name: "Main", component: Main, props:true , children: [
            { path: "/user/list", name: "UserList", component: UserList },
            { path: "/user/add", name: "UserAdd", component: UserAdd },

            // 1. 通过params传参
            // 2. 配置route-link: 
            //    方式一: <router-link to="/user/modify/1">修改用户</router-link>
            //    方式二: <router-link :to="{name:'UserModify',params:{id:2}}">修改用户</router-link>
            // 3. (页面需要:{{$route.params.id}}获取参数)
            // { path: "/user/modify/:id", name: "UserModify", component: UserModify }


            // 1. 通过props传参,(开启props)
            // 2. 配置route-link: 
            //    方式一: <router-link to="/user/modify/3">修改用户</router-link>
            //    方式二: <router-link :to="{name:'UserModify',params:{id:3}}">修改用户</router-link>
            // 3. 页面通过JS获取参数( props:['id'] )
            { path: "/user/modify/:id", name: "UserModify", component: UserModify , props:true }
        ]
    },
    { path : "*" , component:NotFound }
];

export default new VueRouter({
    routes: routes,
    mode: "history"
});
