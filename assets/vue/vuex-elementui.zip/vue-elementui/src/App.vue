<template>
  <div id="app">
    <!-- 配置路由组件 -->
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App',
  created(){
    window.addEventListener("beforeunload",()=>{
      sessionStorage.setItem('state',JSON.stringify(this.$store.state));
    });

    if(sessionStorage.getItem('state')){
      this.$store.replaceState(Object.assign({},this.$store.state,JSON.parse(sessionStorage.getItem('state'))));
    } //end
  }
}
</script>

<style>

</style>
