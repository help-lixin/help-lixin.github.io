import Vue from 'vue'
import VueRouter from 'vue-router'
// 导入路由配置
import router from './router/index.js'
import App from './App'
// 导入vuex
import Vuex from 'vuex'
// 导入vuex的配置
import store from './store/index.js'

// 导入axios
import axios from 'axios'


import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';


Vue.use(VueRouter);
Vue.use(ElementUI);
Vue.use(Vuex);
// 声明使用axios
Vue.prototype.axios=axios;

Vue.config.productionTip = false


// 每次路由跳转之前都会执行该方法
// router.beforeEach((to,from,next)=>{
//   let isLogin = sessionStorage.getItem('isLogin');
//   console.log("===========================");
//   // 注销时,清空session
//   if(to.path == '/logout') {  // 判断是否为退出登录,退出登录,则清空session中信息,并跳到登录页面
//     console.log("logout");
//     sessionStorage.clear();
//     // 跳转到登录页面
//     next({ path:"/login"});
//   } else if(to.path == '/login'){  //判断请求是否为登录
//     // 如果已经登录过了,则跳到首页.
//     if(isLogin != null){
//       // 获取到用户名,跳转到首页
//       let userName = sessionStorage.getItem('userName');
//       // params只能通过:name(路由中指定的名称)来实现,不能像上面那样,指定:path
//       // next({name:"Main",params:{userName:userName}});
//       next({name:"Main",params:{userName:userName}});
//     }
//   } else if(isLogin == null){
//     // 跳转到登录页面
//     next({ path:"/login"});
//   }
//   // 跳到下一个
//   next();
// });

new Vue({
  el: '#app',
  router,
  store,
  render: h => h(App)
})
