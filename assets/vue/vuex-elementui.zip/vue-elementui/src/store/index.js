import Vue from 'vue'
// 导入vuex
import Vuex from 'vuex'

Vue.use(Vuex);

// 注意:state/getters/mutaions 名称都是固定了的

// state相当于一个全局对象,用于保存所有组件公共(shard)的数据
// 由于刷新页面,数据会丢失,所以:在App.vue绑定事件(unload),一旦刷新就保存state到sessionStorage里.
// const state = sessionStorage.getItem('state') != null ?  
//              JSON.parse(sessionStorage.getItem('state')) : { 
//                  user : {
//                      userName : ""
//                 } };


const state = {
    user : {
        userName : ""
    }
};

// 获取state的最新状态(这是一个计算属性值)
const getters = {
    getUser(state){
        return state.user;
    }
};

// 修改state值的方法(这个方法会同步执行)
const mutations = {
    updateUser(state,user){
        state.user = user;
    }
};

// 异步执行:updateUser
const actions = {
    asyncUpdateUser(context,user){
        context.commit("updateUser",user);
    }
}

export default new Vuex.Store({
    state,
    getters,
    mutations,
    actions
});