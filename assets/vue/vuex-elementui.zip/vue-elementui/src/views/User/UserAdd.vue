<template>
    <div>
        用户添加
    </div>
</template>

<script>
export default {
    name : "UserAdd"    
}
</script>

<style>

</style>