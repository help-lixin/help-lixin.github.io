package help.lixin.common.inject;

import org.junit.Test;

import help.lixin.common.module.CustomerModule;
import help.lixin.common.service.IHelloService;

public class InjectTest {
	
	@Test
	public void testInject() {
		// 定义对象之间的依赖(类似于Spring中的XML或Configuratione)
		Module module = new CustomerModule();
		
		ModulesBuilder builder = new ModulesBuilder();
		builder.add(module);
		// 创建:Injector,并设置对象与对象之间的依赖
		Injector inject = builder.createInjector();
		
		// 获得Bean
		IHelloService helloService = inject.getInstance(IHelloService.class);
		helloService.sayHello();
	}
}
