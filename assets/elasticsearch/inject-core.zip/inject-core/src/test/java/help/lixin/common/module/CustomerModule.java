package help.lixin.common.module;

import help.lixin.common.inject.AbstractModule;
import help.lixin.common.inject.Singleton;
import help.lixin.common.inject.name.Names;
import help.lixin.common.service.IHelloService;
import help.lixin.common.service.impl.HelloService;
import help.lixin.common.util.CommonLog;

public class CustomerModule extends AbstractModule {

	@Override
	protected void configure() {
		bind(IHelloService.class).to(HelloService.class).in(Singleton.class);
		bind(CommonLog.class).toInstance(new CommonLog());
		bindConstant().annotatedWith(Names.named("port")).to(8080);
	}
}
