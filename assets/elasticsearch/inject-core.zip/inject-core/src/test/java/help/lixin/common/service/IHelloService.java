package help.lixin.common.service;

public interface IHelloService {
	void sayHello();
}
