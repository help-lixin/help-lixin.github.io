package help.lixin.common.util;

import java.io.PrintStream;

public class CommonLog {
	private static final PrintStream OUT = System.out;

	public void println(String line) {
		OUT.append(line).append("\n");
	}
}
