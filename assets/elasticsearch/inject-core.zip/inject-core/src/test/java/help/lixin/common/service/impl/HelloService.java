package help.lixin.common.service.impl;

import help.lixin.common.inject.Inject;
import help.lixin.common.inject.name.Named;
import help.lixin.common.service.IHelloService;
import help.lixin.common.util.CommonLog;

public class HelloService implements IHelloService {

	private CommonLog commonLog;
	private int port;

	@Inject
	public HelloService(CommonLog commonLog, @Named("port") int port) {
		this.commonLog = commonLog;
		this.port = port;
		this.commonLog.println("=====================HelloService init========================");
	}

	@Override
	public void sayHello() {
		commonLog.println("*********************start bind port:" + port + "*****************");
		commonLog.println("*********************say Hello*****************");
	}
}
