package help.lixin.spring;

import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

public class FutureTest {
	public static void main(String[] args) throws Exception {
//		Callable<String> callable = new Callable<String>() {
//			@Override
//			public String call() throws Exception {
//				TimeUnit.SECONDS.sleep(10);
//				return "hello world!!!";
//			}
//		};
//		FutureTask<String> futureTask = new FutureTask<String>(callable);
//		// 需要启动一个线程去执行
//		
//		new Thread(futureTask).start();
//		String value = futureTask.get();
//		System.out.println("value= " + value);
//		CountDownLatch latch = new CountDownLatch(1);
//		latch.await();
	}
}
