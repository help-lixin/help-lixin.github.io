package help.lixin.spring;

public class Client {
	public static void main(String[] args) throws Exception {
//		HttpClientResponse response =
//                HttpClient.create()
//                          .headers(headers->headers.add("title", "123456"))
//                          .get()                      
//                          .uri("http://localhost:8080/hello") 
//                          .response()
//                          .block();
//		CountDownLatch latch = new CountDownLatch(1);
//		latch.await();
    }
}
