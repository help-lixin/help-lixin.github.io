package help.lixin.spring;

public class Server {
	public static void main(String[] args) throws Exception {
//		HttpServer.create()
//		.host("localhost").port(8080)
//        .route(routes ->
//            routes.get("/hello",
//                       (request, response) -> 
//            					   response.addHeader("pwd", "123")
//            					   .status(HttpResponseStatus.OK)
//                                   .header(HttpHeaderNames.CONTENT_LENGTH, "12")
//                                   .sendString(Mono.just("Hello World!"))))
//        .bindNow();
//		
//		CountDownLatch latch = new CountDownLatch(1);
//		latch.await();
	}
}
