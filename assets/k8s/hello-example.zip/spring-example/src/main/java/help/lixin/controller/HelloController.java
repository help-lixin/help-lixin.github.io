package help.lixin.controller;


import java.io.Serializable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
	private Logger logger = LoggerFactory.getLogger(HelloController.class);
	
	@Value(value = "${instnace.name}")
	private String instanceName;

	@GetMapping("/user/{id}")
	public User get(@PathVariable("id") String id) {
		User user = new User();
		user.setAge(25);
		user.setUserName("张三");
		user.setId("test-"+id);
		return user;
	}

	@GetMapping("/hello")
	public String hello() {
		logger.debug("request hello!!!" + instanceName);
		return "Hello World!!!" + instanceName;
	}
}


class User implements Serializable {
	private static final long serialVersionUID = 6512941288222913484L;
	private String id;
	private String userName;
	private int age;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
}