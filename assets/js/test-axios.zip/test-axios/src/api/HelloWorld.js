const axios = require('axios');

export default class HelloWorld {
	// 定义hello方法
	hello(url,callback) {
		axios.get(url)
		.then(function(response) {
			callback(response);
		})
		.catch(function(error) {
			console.log(error);
		});
	}
}