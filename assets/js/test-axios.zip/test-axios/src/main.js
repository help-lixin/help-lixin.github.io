import HelloWorld from "./api/HelloWorld.js"

// 注意:此处的url,不需要写全:http://localhost:8000/devApi/hello
// 此处配置: proxy.target = http://localhost:8080
// proxy.pathRewrite = {'^/devApi':''}
// 1. webpack-dev-server拦截:/devApi/hello 
// 2. 执行正则(proxy.pathRewrite),将:/devApi/hello 替换成: /hello
// 3. 把/hello拼接在:proxy.target后面,变成:http://localhost:8080/hello

let url = "/devApi/hello";
let helloWorld = new HelloWorld();	
let result = helloWorld.hello( url , (res) => {
	if(res.status == 200){
		console.log(res.data);
	}
});
