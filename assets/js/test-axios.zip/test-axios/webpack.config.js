module.exports = {
    entry:  __dirname + '/src/main.js', //打包文件入口
    output: {               //打包文件出口
        path:  __dirname + '/dist',
        filename: '[name].js'
    },
	devServer: {
		contentBase : "./dist",
		host : "localhost",
		port: 8000,
		open:true,
		proxy: {
			"/devApi" : {
				target:'http://localhost:8080',
				pathRewrite:{
					'^/devApi':''
				},
				changeOrigin:true,
				secure : false
			}
		}
	}
}